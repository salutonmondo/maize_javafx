package wf.database;

import wf.RegisterInfo;
import wf.bean.RegistrationInformation;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Created by wadeshu on 18/04/2017.
 */
public class ExportUtil {
    public static void main(String args[]){
        Connection conn = null;
        try {
            BufferedWriter br = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("大会数据导出1.txt")));
            String sql = "select * from registration where 会议报名 like '%,3%'";
            conn = DataBaseUtility.getConnection();
            Statement stm = conn.createStatement();
            ResultSet resultSet = stm.executeQuery(sql);
            for(String tmp: RegistrationInformation.arr){
                br.write(tmp+"\t");
            }
            br.write("\n");
            while(resultSet.next()){
                for(String tmp: RegistrationInformation.arr){
                    String tmpString = resultSet.getString(tmp);
                    br.write(tmpString+"\t");
                }
                br.write("\n");
            }
            br.flush();
            br.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
