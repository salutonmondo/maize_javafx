/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wf.database;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 *
 * @author kpxt
 */
public class LogUtil {

    public static BufferedWriter bw;

    static {
//        try {
//            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("c:/log.txt")));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public static void log(String s) {
//        try {
//            bw.write(s);
//            bw.flush();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}
