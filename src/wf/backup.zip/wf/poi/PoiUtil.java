/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wf.poi;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ddf.EscherColorRef;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wf.bean.RegistrationInformation;
import wf.service.RegistrationService;

/**
 *
 * @author wadeshu
 */
public class PoiUtil {

    public static void importExcel(File file) {
        try {
            OPCPackage pkg = OPCPackage.open(file);
            XSSFWorkbook wb = new XSSFWorkbook(pkg);
            boolean first = true;
            List<HashMap<String,String>> list = new ArrayList<>();
            ArrayList<String> headers = new ArrayList<>();
            for (Sheet sheet : wb) {
                for (Row row : sheet) {
                    if (first) {
                        first = false;
                        for (Cell cell : row) {
                            headers.add(cell.getStringCellValue());
                        }
                        continue;
                    }
                    int index = 0;
                     HashMap<String,String> regMap = new HashMap<>();
                    for (Cell cell : row) {
                        CellType type = cell.getCellTypeEnum();
                        if(type==CellType.STRING){
                            regMap.put(headers.get(index), cell.getStringCellValue());
                            System.out.println("   "+cell.getStringCellValue());
                        }else if(type==CellType.NUMERIC){
                            regMap.put(headers.get(index), cell.getNumericCellValue()+"");
                        }else {
                            regMap.put(headers.get(index), "");
                        }
                        index++;
                    }
                    list.add(regMap);
                    System.out.println("");
                }
            }
            new RegistrationService().saveRegisterInfos(RegistrationInformation.class, null, list);
            pkg.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
